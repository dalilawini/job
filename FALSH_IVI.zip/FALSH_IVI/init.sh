
path1=$(pwd) 
chmod 777 Flash_IVI.sh
cd 
mkdir -p release/Script
mv $path1/Flash_IVI.sh release/Script -v
mv $path1/Config.txt release/Script -v
mv $path1/vespa.sh release/Script -v
mv $path1/ReadMe.txt release/Script -v
cat ReadMe.txt
cd release/Script
chmod 777 *
path2=$(pwd) 
cd 
echo "alias Flash_IVI='$path2/Flash_IVI.sh'">>.bashrc;
sleep 2s;
source .bashrc	
rm -rf $path1/init.sh
echo "thank you"
exit
