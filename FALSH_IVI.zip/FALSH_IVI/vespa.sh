
function Type_Select () 
{
	tput sgr0;
	tput setaf 5;
	echo "What is the Update Mode used "
	tput setaf 6;
	options=("-> VESPA : Reprog" "-> VESPA : Config" "-> VESPA : Calib" "-> VESPA : Software")
	PS3="Choose an option: "
	select opt in "${options[@]}"
	do
		case $opt in
			"-> VESPA : Reprog")	
				CONF;RUC;XTRA;SOFTWARE;
				for i in {1..3}; do python mock_vespa.py -v $vin -s "RDO.CONFIGURATION|$ref,RDO.RUC|$ruc,RDO.XTRA-DATA|$xtra,RDO.SOFTWARE|$soft" -m "$Type" ;sleep 1;done;
				tput setaf 3;
				echo ""
				echo "python mock_vespa.py -v $vin -s \"RDO.CONFIGURATION|$ref,RDO.RUC|$ruc,RDO.XTRA-DATA|$xtra,RDO.SOFTWARE|$soft\" -m \"$Type"\";break;;

			"-> VESPA : Config")	
				CONF;RUC;
				for i in {1..3}; do python mock_vespa.py -v $vin -s "RDO.RUC|$ruc,RDO.CONFIGURATION|$ref" -m "$Type";sleep 1;done;
				tput setaf 3;
				echo ""
				echo "python mock_vespa.py -v $vin -s \"RDO.CONFIGURATION|$ref,RDO.RUC|$ruc\" -m \"$Type\"";break;;

			"-> VESPA : Calib")	
				XTRA;
				for i in {1..3}; do python mock_vespa.py -v $vin -s "RDO.XTRA-DATA|$xtra" -m "$Type";sleep 1;done;
				tput setaf 3;
				echo ""
				echo "python mock_vespa.py -v $vin -s RDO.XTRA-DATA|$xtra -m $Type";break;;

			"-> VESPA : Software")	
				SOFTWARE ;
				for i in {1..3}; do python mock_vespa.py -v $vin -s "RDO.SOFTWARE|$soft" -m "$Type";sleep 1;done;
				tput setaf 3;
				echo ""
				echo "python mock_vespa.py -v $vin -s \"RDO.SOFTWARE|$soft\" -m \"$Type\"";break;;

			*)  echo " Please Retry";;
        	
    		esac
	done
}
function VIN () 
{   	
	if [[ $(adb $IVI_ADB_SERIAL get-state) = "device" ]]; then
		default_reply=$(adb wait-for-device shell cmd DiagAdb Configuration get vin/X/vin|sed '1,2d');
	else 
		default_reply="xxxxxxxxxxx"
	fi
	tput setaf 6;
	read -r -p "VIN: $default_reply ->$(tput setaf 5)Press enter to default selected $(tput setaf 1)OR $(tput setaf 2)set VIN:" vin
	if [[ -z "$vin" ]]; then vin="$default_reply"; fi
	tput setaf 3
	echo "-- vin -> $vin"
	echo ""
}

function type_ () 
{
	default_reply="XDD";
	tput setaf 6;
	read -r -p "TYPE: $default_reply ->$(tput setaf 5)Press enter to default selected  $(tput setaf 1)OR $(tput setaf 2)set Type:" Type
	if [[ -z "$Type" ]]; then Type="$default_reply"; fi
	tput setaf 3
	echo "-- type -> $Type"
	echo ""
}

function CONF () 
{
	tput setaf 5;
	echo "RDO.CONFIGURATION"
	tput setaf 4;
	echo "Ref:"
	tput sgr0;
	read ref
}
function RUC () 
{
	tput setaf 5;
	echo "RDO.RUC"
	tput setaf 4;
	echo "Ref:"
	tput sgr0;
	read ruc
}
function XTRA () 
{
	tput setaf 5;
	echo "RDO.XTRA-DATA"
	tput setaf 4;
	echo "Ref:"
	tput sgr0;
	read xtra
}
function SOFTWARE () 
{
	tput setaf 5;
	echo "RDO.SOFTWARE"
	tput setaf 4;
	echo "Ref:"
	tput sgr0;
	read soft
}
function get_path_file()
{
	search=$(grep -ir tools-master_path  $home_path/release/Script/Config.txt)
    if [ -z "$search" ]; then
		tput setaf 1;
        echo "tools-master path not exist or incorrect please write tools-master_path:your path";
        echo "in Config.txt file" ;
		exit
	else 
		arr=($(echo $search | sed 's/\:/\n/g'));
		path=${arr[1]};	fi 
}
#-------------------------------------------------------------------------------------
cd;
home_path=$(pwd);
get_path_file

tput setaf 3;
echo "Please Remplir with Your information ";
tput setaf 2;
echo "------------------------------------------";


VIN;
type_;
cd $home_path/$path/Step_2/Mock_vespa;
sleep 1s 
Type_Select;
echo ""
echo "tools path:$home_path/$path";
cd 
tput sgr0;
exec bash
