mv .Flash_IVI.sh Flash_IVI.sh
mv .Config.txt Config.txt 
mv .vespa.sh vespa.sh
mv .ReadMe.txt ReadMe.txt
mv .log.sh log.sh

path1=$(pwd) 
cd 

mkdir -p release/Script

cat $path1/ReadMe.txt


mv $path1/Flash_IVI.sh release/Script 
mv $path1/Config.txt release/Script 
mv $path1/vespa.sh release/Script 
mv $path1/ReadMe.txt release/Script 
mv $path1/log.sh release/Script 



cd release/Script
chmod 777 *
path2=$(pwd) 
cd 
echo "alias Flash_IVI='$path2/Flash_IVI.sh'">>.bashrc;
echo "alias log='$path2/log.sh'">>.bashrc;
sleep 2s;
source .bashrc	
rm $path1/init.sh
echo "$(tput setaf 3) ALL FILE MOVED TO $(tput setaf 6)$path2"
echo ""
echo "----------------------NOTE------------------------------"
echo "$(tput setaf 1)Please open new ternimal and lunch this command$(tput setaf 2) Flash_IVI or log"

exit
