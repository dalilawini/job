function check_usb_number 
{
usb_number=$(ls /media/mohamed/ | wc -l )
	if [ $usb_number -eq 0 ]
	then
	echo "$(tput setaf 1)To transfer files, please insert a USB storage device"  
       exit 
	fi

	if [ $usb_number -gt 1 ]
	then
	     usb=$(ls /media/*/)
	     drive=($(echo $usb | sed 's/\:/\n/g'));
	     count=0

		while [ $count -lt $usb_number ]
			do
  				echo  "$count) ${drive[$count]}"
  				count=$((count+1))
			done
		select=9;
			
		while [ $select -ge $usb_number ]
		do
				read -p " *) your number answe : " select
		done	 
		
		if ! [[ "$select" =~ ^[0-9]+$ ]]; then
		echo "$(tput setaf 1)Invalid input. Please enter an integer number"
                   exit

                fi
                usb=${drive[$select]}
                echo $usb
	   fi 

}
check_usb_number
