
#!/bin/bash


function ADB_Check () 
{

	if [[ -z "$(command -v adb)" ]]
	 then
		echo "[ERROR] adb not found in PATH please install it ";
		echo "to instal try : sudo apt install adb ";

		exit;
	fi
	
	 if [[ -z "$(command -v fastboot)" ]]
	 then
		echo "[ERROR] fastboot not found in PATH please install it ";
		echo "to instal try : sudo apt install fastboot";
        exit
	 fi
	 
	if  [[ -z "$(command -v curl)" ]]
	 then
		echo "[ERROR] adb not found in PATH please install it ";
		echo "to instal try : sudo apt install curl";
		exit ;
	fi;
	

}


function Select_IVI_TYPE () 
{
        tput setaf 5;
	echo " 1) Please choose the right IVI type "
        tput setaf 6;
	options=("BAR" "CUB" "DOM" "ANT" "Quit")
	PS3="$(tput setaf 2)--->"
	select opt in "${options[@]}"
	do
		case $opt in
        		"BAR")
			hw_version="BAR";
			hw_version2="CoreDA";
			type_filtre="*ANT*;*CUB*;*DOM*;*EMULATOR*;*xml*" ;
			break
			;;
			"CUB")
			hw_version="CUB";
			hw_version2="FullNav";
			type_filtre="*ANT*;*BAR*;*DOM*;*EMULATOR*;*xml*";
			break
			;;
			"DOM")
			hw_version="DOM";
			hw_version2=FullDom;
			type_filtre="*BAR*;*CUB*;*ANT*;*EMULATOR*;*xml*";
			break
			;;
			"ANT")
			hw_version="ANT";
			hw_version2="ACCESSDA"
			type_filtre="*BAR*;*CUB*;*DOM*;*EMULATOR*;*xml*";
			break
			;;
			"Quit")
			tput setaf 1;echo "exit";exit
			;;
			*) tput setaf 1;echo "Invalid option, try again";    tput setaf 5;;
		esac
	done
	tput sgr0; 
	recursive_value="false"
}

function Select_recovery_mode () 
{
	tput setaf 5;
	echo " 3) What is the mode recovery "
	tput setaf 6;
	options=("NO RESET" "ALL RESET")
	PS3="$(tput setaf 2)--->"
	select opt in "${options[@]}"
	do
		case $opt in
		
			"NO RESET")
				filtre="*AllReset*;*SpecialPackage*";
				recovery_mode="NoReset";
				ftr="*NoReset*";
				break
				;;
		
			"ALL RESET")
       				 filtre="*NoReset*";
					 recovery_mode="AllReset";
					 ftr="*AllReset*";
       				break
            			;;
            	
        		*) 
        			tput setaf 1;
        			echo "Invalid option, try again";
        			tput setaf 2
        			;;
        	
    		esac
	done
	recursive_value="true"
	tput sgr0;
}



#NOTE:
function Select_version () 
{
	check=0;
	while [ $check -eq 0 ]; 
	do
		tput setaf 7;
		echo ""
		read -p " 2) What is the Source Version  ? XX.XX.XX : " source_version 
		echo ""
		
		arr=($(echo $source_version | sed 's/\./\n/g'))
		
		if [ -z "${arr[2]}" ]; then
  			echo "Please Check your Answer"
		else 
 			check=1;
 			if [ ${arr[0]} -gt 99 ] || [ ${arr[0]} -lt 8 ] ;then
         			tput setaf 1;
				echo "please check the first number of version ";
				tput setaf 2;
				echo "exp: Myf1:08.xx.xx or Myf2:11.xx.xx Myf3:16.xx.xx ";
				check=0;
			fi

 			if [ ${arr[1]} -gt 5 ] || [ ${arr[1]} -le 0 ] ;then
 				tput setaf 1;
  				echo "please check the Second number of version ";
         			tput setaf 2;
  				echo "exp: first sprint :xx.01.xx -> third sprint :xx.03.xx  ";
  				check=0;
			fi

			if [ ${arr[2]} -gt 40 ] || [ ${arr[2]} -lt 10 ];then
				tput setaf 1;
				echo "please check the last number of version ";
				tput setaf 2;
				echo "exp: fixe exp:xx.xx.10 -> fixe :xx.xx.30  ";
				check=0;
			fi
	
		fi

	done
}


#NOTE:
function Select_build () 
{
	tput setaf 5;
	echo " 3) What is the build type  "
	tput setaf 6;
	options=("user" "userdebug")
	PS3="$(tput setaf 2)--->"
	select opt in "${options[@]}"
	do
		case $opt in
		
			"user")
					build_filtre="*userdebug.*";
					build_type="USER";           
					build_type_afficher="user";
					break
					;;
		
			"userdebug")
					build_filtre="*user.*";     
					build_type="USERDEBUG";
       				build_type_afficher="userdebug";
       				break
            			;;
            	
        		*) 
        			tput setaf 1;
        			echo "Invalid option, try again";
        			tput setaf 5
        			;;
        	
    		esac
	done
	tput sgr0;
}





function download_packages () 
{	
	if  [ -f jfrog ];then	
		echo "jfrog binary exist ..."
	else 
    	curl -fL https://getcli.jfrog.io | sh 

	fi

	sleep 1s;
	
    	tput setaf 4;
	echo "******************START DOWNLOAD******************"   
    	tput setaf 2;
	echo "->             $hw_version.$source_version.$build_type_afficher $recovery_mode       <-"
    	tput setaf 4;
	echo "**************************************************"
    	tput sgr0;
    	sleep 1s;
	
	./jfrog rt download --url https://artifactory.dt.renault.com/artifactory --apikey "AKCp8k8EDG4pEeq6ibgyhvAqw1xy3SCN5qkBfTqGrqiX156QMYYeMcJTicnrswBSu9HWQ4mhw" --include-dirs=$recursive_value --flat=false --recursive=false --exclusions=$filtre  $url_path |tee /tmp/$hw_version.$source_version.log 
	
}

function fastboot_check_file ()
{


	if  [ -f $path/*$hw_version*.$build_type_afficher.tar.gz ];then
		tput setaf 6;
		echo "FILE EXIST"
	else 
   		 tput setaf 1;
		echo "$hw_version.$source_version.$build_type_afficher NOT EXIST IN YOUR HOST  "
		exit 
	fi
	tput sgr0;
}

function check_download  ()
{
	path=$home_path/release/LGE/RELEASE.$source_version;
	out=$( cat /tmp/$hw_version.$source_version.log |grep -i \"success\": );
	msg=($( echo $out | sed 's/\:/\n/g'))
	if [ ${msg[1]} = "0," ];then
	 	tput setaf 1;
		echo "$hw_version.$source_version.$build_type_afficher NOT EXIST IN SERVER "
		exit ;
	else 
		tput setaf 6;
		echo "FILE VERIFICATION SUCCESSFUL"
	fi
	tput sgr0;
	rm -r /tmp/$hw_version.$source_version.log;

}


function get_local_data_config () 
{       
	tput setaf 6;
	echo "                        --------"      ;                   
	echo "*******************  Get DATA From Config.txt  ********************";
	echo "                        --------";
     	tput setaf 3;
	echo ""; 
    	search=$(grep -ir vin  $home_path/release/Script/Config.txt)
    	if [ -z "$search" ]; then
		tput setaf 1;
        	echo "VIN not exist or incorrect please write VIN:VF1X000000000000";
        	echo "in Config.txt file" ;
	else 
		arr=($(echo $search | sed 's/\:/\n/g'));
		vin=${arr[1]};
		echo "VIN:$vin";
	fi 
    
	search=$(grep -ir SN $home_path/release/Script/Config.txt)
	if [ -z "$search" ]; then
		tput setaf 1;
        	echo "Serial number not exist or incorrect please write  SN:LG200000000000000000"
        	echo "in Config.txt file" 
	else 
		arr=($(echo $search | sed 's/\:/\n/g'));
		SN=${arr[1]}
		echo "SN:$SN "
	fi 
    
	search=$(grep -ir vehicle_configs_path $home_path/release/Script/Config.txt)
	if [ -z "$search" ]; then
		tput setaf 1;
        	echo "Vehicle config path not exist or incorrect please write  vehicle_configs_path:your path"
        	echo "in Config.txt file" 
	else 
		arr=($(echo $search | sed 's/\:/\n/g'));
		vehicle_config_path=$home_path/${arr[1]};
		echo "path : $vehicle_config_path"
	fi 
	
	tput sgr0;
}

function FOTA_parameters ()
{
	tput setaf 2;
	echo""
	echo "                                -----                                          "
	echo "************PUSH VIN & SERIAL NUMBER & PA_HELPER & FOTA BEARER**************** "
	echo "                                -----                                          "
	echo ""
	tput sgr0;
	
	adb wait-for-device;
	sleep 1s;
	echo "-->     STATIC MODE ";adb shell cmd DiagAdb setBootMode STATIC1;
	sleep 1s;
	echo "-->     HARD RESET ";adb shell cmd DiagAdb hardReset;
	sleep 2s
	echo "-->     WAIT FOR DEVICE "
	sleep 3s
	adb wait-for-device;
	echo "" 
	sleep 5s
	tput setaf 6;
	echo ""
	echo "-----------------VIN--------------------" ;
	tput sgr0;       
	adb wait-for-device;adb shell cmd DiagAdb Configuration set vin/X/vin:"$vin";
	        
	sleep 1s;	
	tput setaf 6;
	echo ""
	echo "-------------SERIAL NUMBER-------------"
	tput sgr0;
	adb wait-for-device;adb shell cmd DiagAdb Configuration set ecu_serial_number_data_identifier/X/ecu_serial_number_data_identifier:"$SN";
	
	sleep 1s;
	tput setaf 4;
	echo ""
	tput sgr0;	
	adb wait-for-device;adb shell su 0 "pa_helper 3 sit";
	
	sleep 1s;
	tput setaf 6;
	echo "------------SET WIFI+IVC CONNECTION---------------";
	echo ""
	tput sgr0;
	adb shell cmd DiagAdb Configuration set sys_info_config/fota/fota_bearer:0
	sleep 1s;
	echo ""
	echo "-->     NORMAL MODE ";sleep 1s;adb shell cmd DiagAdb setBootMode NORMAL;
	sleep 1s;
	echo "-->     HARD RESET ";sleep 1s;adb shell cmd DiagAdb hardReset;
	echo""
	sleep 5s;	
}

function fastboot_function () 
{

	cd  ;
	sleep 1s;
	
	if  [ -d /tmp/RELEASE_* ];then
		tput setaf 1;
		echo "remove old directory "
		rm -r /tmp/RELEASE_* ;
		echo ""
	fi

	fastboot_check_file;

	tput setaf 5;
	echo "EXTRACT RELEASE FILE ";
	tput sgr0;
	tar -xvf $path/*$hw_version*.$build_type_afficher.tar.gz -C /tmp ;
	sleep 1s;
	cd /tmp/RELEASE_*;
	sleep 1s;
	chmod 777 fastboot_*_blank_flash.sh;
	clear;

	tput setaf 3;
	echo "****************FLASHING START*************";
	
	if [[ -z "$(fastboot devices)" ]]; then
		tput setaf 5;
		echo""
		echo "**************reboot to bootloade**********"
		tput sgr0;
		adb wait-for-device && adb reboot bootloader;
		sleep 5s;
	else   
		tput setaf 6;
       		echo "fastboot devices -> OK"
		tput sgr0;
	fi

	./fastboot*flash.sh ;
	
	
	tput setaf 4;
	echo "---------------Removed directory--------------- ";
	tput sgr0;
	fastboot reboot
	sleep 1s;
	rm -r /tmp/RELEASE_*;
	sleep 1s;



	adb wait-for-device;
	sleep 5s;
	
	
	tput sgr0;
#--------------------------
}
	

function push_vehicle_config () 
{
	
	sleep 2s;
	tput setaf 6;
	echo "                        --------"      ;                   
	echo "*******************  VEHICLE CONFIG  ********************";
   	echo "                        --------";

	if  [ -d $vehicle_config_path ];then
		echo "";                        
		tput sgr0;
		adb wait-for-device
		sleep 1s
		echo "-->     STATIC MODE ";adb shell cmd DiagAdb setBootMode STATIC1&
		sleep 1s
		echo "-->     HARD RESET ";adb shell cmd DiagAdb hardReset&
		sleep 1s
		adb wait-for-device;
		echo "-->     CALL SCRIPT "
		sleep 5s;
		echo "";
		adb wait-for-device ;	sleep 1s; cd $vehicle_config_path;./push_vehicle_config.sh;	
		sleep 1s;
		adb wait-for-device shell cmd DiagAdb setBootMode NORMAL;
		sleep 1s;
		adb shell cmd DiagAdb hardReset;
		sleep 1s;
    else 
		tput setaf 1;
		echo "VHECLE CONFIG DIRECTORY NOT EXIST "
		echo ""
		tput setaf 3;
		echo "please go to $home_path/release/Script/Config.txt"
		tput setaf 6;
		echo "and add your path vehicle_configs_path:$(tput setaf 2)EXP/HOME/xx/xx"
		exit
	fi
}

function check_usb_number()
{
 

usb_number=$(ls /media/$(whoami)/ | wc -l )
	if [ $usb_number -eq 0 ]
	then
	echo "$(tput setaf 1)To transfer files, please insert a USB storage device"  
       exit 
	fi
	usb=$(ls /media/$(whoami)/);

	if [ $usb_number -gt 1 ]
	then
	     echo "$(tput setaf 6)Please Select a USB device to continue$(tput sgr0)"
	     usb=$(ls /media/$(whoami)/)
	     drive=($(echo $usb | sed 's/\:/\n/g'));
	     count=0

		while [ $count -lt $usb_number ]
			do
  				echo  "$count) ${drive[$count]}"
  				count=$((count+1))
			done
		select=9;
			
		while [ $select -ge $usb_number ]
		do
				read -p " *) your number answe : " select
		done	 
		
		if ! [[ "$select" =~ ^[0-9]+$ ]]; then
		echo "$(tput setaf 1)Invalid input. Please enter an integer number"
                   exit

                fi
                usb=${drive[$select]}
                echo "$(tput setaf 3)USB device selected: $(tput setaf 6)$usb $(tput sgr0)"
	   fi 

}

function send_reco_to_usb()
{
	cd ;
	sleep 1
	path_reco=release/LGE/RELEASE.$source_version/USBUpgrade/RecoveryPackage/$hw_version2/$build_type/SIT;
		
		if  [ -d /tmp/$ftr ];then
		tput setaf 1;
		echo "remove old directory "
		rm -r /tmp/$ftr ;
		echo ""
	fi
	    tput setaf 6;
    	echo "EXTRACT FILE "
    	tput setaf 3;
	tar -xvf $path_reco/$ftr -C /tmp;
    	

	sha256_original=$(sha256sum /tmp/$ftr/Update.zip)
	sha256_original=($(echo $sha256_original | sed 's/\:/\n/g'));

    cd

	
	tput setaf 6;
    	echo "READY FOR SEND TO USB DISK: $usb"

	mkdir -p /media/$(whoami)/$usb/USB_UPDATE
	sleep 2s
	tput setaf 3;
 	cp /tmp/$ftr/Update.zip /media/$(whoami)/$usb/USB_UPDATE -vf 
    tput setaf 6;
    echo "WAIT FOR DATA VERIFICATION"
	sync 
	sleep 1s
	sha256_copie=$(sha256sum /media/$(whoami)/$usb/USB_UPDATE/Update.zip)
	sha256_copie=($(echo $sha256_copie | sed 's/\ /\n/g'));
   
	if [ ${sha256_original[0]} = ${sha256_copie[0]} ]
	 then
		echo "copied successful";
		sync
		sleep 5s
		rm -r /tmp/$ftr
		tput sgr0; 

	else 
		tput setaf 1;
		echo "This file is incorepted "
		rm -r /tmp/$ftr
		tput sgr0; 
		exit

	fi

}

function fastboot_check ()
{
	tput setaf 1;
	default_reply=n
   	read -r -p "[INFO] $(tput setaf 2)Hello! To get started, please select one of the following options:$(tput sgr0) 
y. Fastboot + push config + fota parameter
n. Fastboot
$(tput setaf 6) response [y/n] [n]!: " response
  	if [[ -z "$response" ]]; then response="$default_reply"; fi	  
}

function Advence()
{
	tput setaf 6;
 	options=("Push Config" "FOTA parameters" "Fastboot Download" "OTA Download" "Vespa" "Quit" )
	PS3="$(tput setaf 2)--->"
	select opt in "${options[@]}"
	do
		case $opt in

			"Push Config")
			get_local_data_config;
			push_vehicle_config;
			break
			;;
			"FOTA parameters")
			get_local_data_config;
			FOTA_parameters;
			break
			;;
			"Fastboot Download")
			Select_IVI_TYPE ;
   			Select_version ;
   			Select_build  ;
			url_path=loire/release/LGE/RELEASE.$source_version/;
			filtre="$build_filtre;$type_filtre";
   			download_packages;
   			check_download;
			break
			;;
			"OTA Download")
				tput setaf 2;
			echo "                        --------"      ;                   
			echo "*******************  OTA Download  ********************";
			echo "                        --------";
			echo "";    
			Select_IVI_TYPE ;
   			Select_version ;
			url_path=loire/release/LGE/RELEASE.$source_version/OTA/USERDEBUG/;
			filtre="*target*;$type_filtre";
			download_packages;
			check_download;
			break 
			;;
			"Vespa")
			if  [[ -z "$(command -v python3)" ]]
	 		then
	         		tput setaf 1;
				echo "[ERROR] Python3 not found  please install it ";
				tput sgr0; 
				exit
			fi;
			$home_path/release/Script/vespa.sh
			exit
			;;
			"Quit")
			tput setaf 1;echo "BEY BEY";exit
			;;
			
			*) tput setaf 1;echo "Invalid option, try again";    tput setaf 5;;
		esac
	done	

}

#----------------------------------------CODE PART----------------------------------------

   
	ADB_Check
	cd;
	home_path=$(pwd);
	
	tput setaf 2;
	echo ""
	echo "-------------------------WELCOM IN SMART FASTBOOT----------------------"
        echo "";echo "";
	
	tput setaf 5;
	echo " 1) Please choose the right option "
	tput setaf 6;

	options=("SMART FASTBOOT" $(tput setaf 2)"RECOVERY" $(tput setaf 3)"ADVENCE" $(tput setaf 7)"Quit" )
	PS3="$(tput setaf 2)--->"
	select opt in "${options[@]}"
	do
		case $opt in
	
			
        		"SMART FASTBOOT")
			fastboot_check;
			Select_IVI_TYPE ;
   			Select_version ;
   			Select_build  ;
			url_path=loire/release/LGE/RELEASE.$source_version/;
			filtre="$build_filtre;$type_filtre";
   			download_packages;
			check_download;	
   			fastboot_function;
			echo $response
    		if [[ "$response" =~ ^([yY][eE][sS]|[yY])+$ ]]; then
			 
				for i in {1..10}; do
   					echo ""
				done;
				get_local_data_config
				for i in {1..10}; do
   					echo ""
				done;
   				push_vehicle_config;
   				for i in {1..20}; do
   					echo ""
				done;
   				FOTA_parameters;
			fi
   			break
			;;
			$(tput setaf 2)"RECOVERY")
			check_usb_number;
			Select_IVI_TYPE ;
   			Select_version ;
   			Select_build  ;
			Select_recovery_mode;		
			url_path=loire/release/LGE/RELEASE.$source_version/USBUpgrade/RecoveryPackage/$hw_version2/$build_type/SIT/;
			download_packages;
			check_download;
			send_reco_to_usb;
            break
			;;

			$(tput setaf 3)"ADVENCE")
			Advence ;
			break
			;;
			$(tput setaf 7)"Quit")
			tput setaf 1;echo "BEY BEY";exit
			break;;

			*) tput setaf 1;echo "Invalid option, try again";    tput setaf 5;;
		esac
	done


   	tput setaf 4;
	echo "THANK YOU -> EVERY THINK IS SUCCESSFUL <-"

    	tput setaf 6;
	echo "******* MISSION COMPLETE FOR:**************"   
   	tput setaf 2;
	echo "$hw_version.$source_version.$build_type_afficher  $recovery_mode"
	echo "************************************"
    	tput sgr0;
cd
exec bash
