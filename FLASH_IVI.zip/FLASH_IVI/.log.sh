

year=$(date +"%Y")
month=$(date +"%h")
day=$(date +"%d")
time=$(date +%Hh%M)

mkdir -p ~/release/Script/Logs/$year/$month/$day/$time;

adb logcat >~/release/Script/Logs/$year/$month/$day/$time/Full.log&

adb logcat -G 16M  && adb logcat  -b all -v color -s "AllianceUpdateManager","AllianceCarUpdateManager", "AllianceCarUpdateService","Ipl", "EventIntentService","ClientService","HmiEventHandler","BasicService","redbend","FotaSecurityHandler","UpdateSecurity" |tee ~/release/Script/Logs/$year/$month/$day/$time/Fota.log

tput setaf 7

echo "*----------------------------------------------------------------------------------------------------*"
echo "-                     *-------------------------------------------*                                  -"
echo "-                                    ----*----                                                       -"
tput setaf 6
	options=("Save" "Not Save")
	PS3="$(tput setaf 2)--->"
	select opt in "${options[@]}"
	do
		case $opt in
        		"Save")
        		default_reply=$time
   			read -r -p "[INFO] $(tput setaf 1)[default=time] $(tput setaf 2) Please enter a name for this log: $(tput setaf 6)" response
  			if [[ -z "$response" ]]; then
  			response="$default_reply";  			
  			echo "$(tput setaf 3)Creating logs folder:$(tput setaf 6) $response ...";
  			else 
  			mv ~/release/Script/Logs/$year/$month/$day/$time ~/release/Script/Logs/$year/$month/$day/$response;
  			echo "$(tput setaf 3)path logs : ~/release/Script/Logs/$year/$month/$day/$time/$response ";
  			 fi	
        		break;;
        		
                	"Not Save")
                	rm ~/release/Script/Logs/$year/$month/$day/$time -r
  			echo "$(tput setaf 1)Removing logs folder: $time ...";
        		break;;
        		
        		
			*) tput setaf 1;echo "Invalid option, try again";    tput setaf 5;;
		esac
	done


